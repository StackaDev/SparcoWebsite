import React from "react";

function ExploreQualtySliderItem() {
  return (
    <div>
      <img className="img-fluid" alt="" src="https://picsum.photos/640/480" />
      <h3 className="product-name">
        LOREM
        <br />
        IPSUM PRODUCT
      </h3>
    </div>
  );
}

export default ExploreQualtySliderItem;
